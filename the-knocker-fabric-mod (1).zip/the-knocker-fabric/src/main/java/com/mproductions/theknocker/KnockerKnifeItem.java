package com.mproductions.theknocker;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;

public class KnockerKnifeItem extends Item {

    public KnockerKnifeItem(Properties properties) {
        super(properties);
    }

    /**
     * The Knocker's knife deals fast, light damage — consistent with the original mod's
     * low-damage-but-fast-attack-speed design.
     */
    public float getAttackDamage() {
        return 3.0f; // Low damage, but The Knocker attacks very fast
    }
}
