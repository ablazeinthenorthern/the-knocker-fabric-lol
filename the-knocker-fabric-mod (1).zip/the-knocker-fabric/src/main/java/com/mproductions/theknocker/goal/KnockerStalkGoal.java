package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * The Knocker lurks at the edge of visibility.
 * When a player looks directly at him, he may teleport away (or jumpscare first).
 * This is the core "stalking" behavior — he watches, but doesn't commit.
 */
public class KnockerStalkGoal extends Goal {

    private final KnockerEntity knocker;
    private Player stalkedPlayer;
    private int stalkTimer;
    private static final double STALK_DISTANCE = 20.0;
    private static final double LOOK_THRESHOLD = 0.98; // Dot product threshold for "looking at"

    public KnockerStalkGoal(KnockerEntity knocker) {
        this.knocker = knocker;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return knocker.getPhase() == KnockerEntity.PHASE_STALKING
            && !knocker.level().isClientSide;
    }

    @Override
    public void start() {
        stalkTimer = 0;
        stalkedPlayer = knocker.level().getNearestPlayer(knocker, 64.0);
    }

    @Override
    public void tick() {
        if (stalkedPlayer == null || !stalkedPlayer.isAlive()) {
            stalkedPlayer = knocker.level().getNearestPlayer(knocker, 64.0);
            return;
        }

        double dist = knocker.distanceTo(stalkedPlayer);
        stalkTimer++;

        // Look at the player menacingly
        knocker.getLookControl().setLookAt(stalkedPlayer, 30.0f, 30.0f);

        // Move to preferred stalk range (about 16–24 blocks away)
        if (dist > STALK_DISTANCE + 4) {
            knocker.getNavigation().moveTo(stalkedPlayer, 1.0);
        } else if (dist < STALK_DISTANCE - 4) {
            knocker.getNavigation().stop();
        }

        // Check if player is looking at Knocker
        if (isPlayerLookingAt(stalkedPlayer)) {
            // Teleport away — he vanishes when seen
            if (knocker.random.nextFloat() < 0.7f) {
                teleportAway();
            }
            // 30% chance: stay and trigger a jumpscare (handled by JumpscareGoal)
        }
    }

    private boolean isPlayerLookingAt(Player player) {
        Vec3 playerLook = player.getLookAngle().normalize();
        Vec3 toKnocker = knocker.position().subtract(player.position()).normalize();
        return playerLook.dot(toKnocker) > LOOK_THRESHOLD;
    }

    private void teleportAway() {
        // Teleport to a dark spot within 32–64 blocks
        for (int attempt = 0; attempt < 16; attempt++) {
            double dx = (knocker.random.nextDouble() - 0.5) * 80;
            double dz = (knocker.random.nextDouble() - 0.5) * 80;
            BlockPos target = knocker.blockPosition().offset((int) dx, 0, (int) dz);
            if (knocker.level().getBrightness(net.minecraft.world.level.LightLayer.BLOCK, target) < 3) {
                knocker.teleportTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5);
                return;
            }
        }
        // Fallback: just teleport somewhere
        knocker.teleportTo(
            knocker.getX() + (knocker.random.nextDouble() - 0.5) * 48,
            knocker.getY(),
            knocker.getZ() + (knocker.random.nextDouble() - 0.5) * 48
        );
    }
}
