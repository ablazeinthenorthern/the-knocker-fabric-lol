package com.mproductions.theknocker.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class TheKnockerClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Register entity renderer
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(
            com.mproductions.theknocker.TheKnockerMod.KNOCKER_ENTITY_TYPE,
            KnockerEntityRenderer::new
        );
    }
}
