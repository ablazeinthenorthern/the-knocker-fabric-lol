package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * When the player looks directly at The Knocker, there's a chance he jump-scares them.
 * This sends a jumpscare packet to the client (sound + brief screen effect).
 */
public class KnockerJumpscareGoal extends Goal {

    private final KnockerEntity knocker;
    private int cooldown = 0;
    private static final int JUMPSCARE_COOLDOWN = 400; // 20 seconds between jumpscares
    private static final double LOOK_THRESHOLD = 0.97;
    private static final double MAX_JUMPSCARE_DIST = 24.0;

    public KnockerJumpscareGoal(KnockerEntity knocker) {
        this.knocker = knocker;
        this.setFlags(EnumSet.noneOf(Flag.class));
    }

    @Override
    public boolean canUse() {
        return cooldown <= 0 && !knocker.level().isClientSide;
    }

    @Override
    public boolean canContinueToUse() {
        return false; // One-shot per activation
    }

    @Override
    public void tick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        Player nearest = knocker.level().getNearestPlayer(knocker, MAX_JUMPSCARE_DIST);
        if (nearest == null) return;

        if (isPlayerLookingAt(nearest) && knocker.random.nextFloat() < 0.3f) {
            triggerJumpscare(nearest);
            cooldown = JUMPSCARE_COOLDOWN;
        }
    }

    private boolean isPlayerLookingAt(Player player) {
        Vec3 playerLook = player.getLookAngle().normalize();
        Vec3 toKnocker = knocker.position().subtract(player.position()).normalize();
        double dot = playerLook.dot(toKnocker);
        return dot > LOOK_THRESHOLD;
    }

    private void triggerJumpscare(Player player) {
        // Play a loud, startling sound at the player's position
        knocker.level().playSound(
            null,
            player.blockPosition(),
            SoundEvents.GHAST_SCREAM,
            SoundSource.HOSTILE,
            1.5f,
            0.5f + knocker.random.nextFloat() * 0.5f
        );

        // Also play a knock sound
        knocker.level().playSound(
            null,
            player.blockPosition(),
            SoundEvents.WOOD_HIT,
            SoundSource.HOSTILE,
            1.0f,
            0.6f
        );

        // Send a title message to the player for jumpscare effect
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(
                net.minecraft.network.chat.Component.empty()
            ));
        }
    }
}
