package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/**
 * The Knocker finds a door or trapdoor near the player's known home position
 * and "knocks" on it — plays knocking sounds, creating dread for any player
 * who is inside.
 */
public class KnockerDoorGoal extends Goal {

    private final KnockerEntity knocker;
    private BlockPos targetDoor;
    private int knockTimer = 0;
    private int knockCount = 0;
    private static final int MAX_KNOCKS = 3;
    private static final int KNOCK_INTERVAL = 12; // ticks between knocks
    private static final int COOLDOWN_AFTER_KNOCK = 600; // 30 seconds before knocking again
    private int cooldown = 0;

    public KnockerDoorGoal(KnockerEntity knocker) {
        this.knocker = knocker;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (knocker.level().isClientSide) return false;
        if (cooldown > 0) { cooldown--; return false; }
        if (knocker.getPhase() < KnockerEntity.PHASE_KNOCKING) return false;

        // Try to find a door near the known home position or nearest player
        targetDoor = findNearbyDoor();
        return targetDoor != null;
    }

    @Override
    public boolean canContinueToUse() {
        return knockCount < MAX_KNOCKS && targetDoor != null;
    }

    @Override
    public void start() {
        knockTimer = 0;
        knockCount = 0;
        // Navigate to the door
        if (targetDoor != null) {
            knocker.getNavigation().moveTo(
                targetDoor.getX() + 0.5,
                targetDoor.getY(),
                targetDoor.getZ() + 0.5,
                1.1
            );
        }
    }

    @Override
    public void tick() {
        if (targetDoor == null) return;

        // Move toward door
        double dist = knocker.blockPosition().distSqr(targetDoor);
        if (dist > 9) { // More than 3 blocks away
            knocker.getNavigation().moveTo(
                targetDoor.getX() + 0.5,
                targetDoor.getY(),
                targetDoor.getZ() + 0.5,
                1.1
            );
            return;
        }

        // We're at the door — knock!
        knockTimer++;
        if (knockTimer >= KNOCK_INTERVAL) {
            knockTimer = 0;
            performKnock();
            knockCount++;
        }
    }

    @Override
    public void stop() {
        knocker.getNavigation().stop();
        knocker.setHasKnocked(true);
        cooldown = COOLDOWN_AFTER_KNOCK;
        targetDoor = null;
    }

    private void performKnock() {
        if (targetDoor == null) return;

        // Play knocking sound — audible through walls to the player
        knocker.level().playSound(
            null,
            targetDoor,
            SoundEvents.WOOD_HIT,
            SoundSource.HOSTILE,
            1.2f,
            0.8f + knocker.random.nextFloat() * 0.4f
        );

        // Alert nearby players
        Player nearestPlayer = knocker.level().getNearestPlayer(knocker, 32.0);
        if (nearestPlayer != null) {
            knocker.level().playSound(
                null,
                nearestPlayer.blockPosition(),
                SoundEvents.WOOD_HIT,
                SoundSource.HOSTILE,
                0.9f,
                0.7f
            );
        }
    }

    private BlockPos findNearbyDoor() {
        BlockPos searchCenter;

        // Prefer to knock at the known home position
        if (knocker.getKnownHomePos().isPresent()) {
            searchCenter = knocker.getKnownHomePos().get();
        } else {
            Player nearest = knocker.level().getNearestPlayer(knocker, 48.0);
            if (nearest == null) return null;
            searchCenter = nearest.blockPosition();
        }

        // Search a 16x4x16 area for a door
        for (int dx = -8; dx <= 8; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -8; dz <= 8; dz++) {
                    BlockPos candidate = searchCenter.offset(dx, dy, dz);
                    BlockState state = knocker.level().getBlockState(candidate);
                    if (state.is(BlockTags.DOORS) || state.is(BlockTags.TRAPDOORS)) {
                        return candidate;
                    }
                }
            }
        }
        return null;
    }
}
