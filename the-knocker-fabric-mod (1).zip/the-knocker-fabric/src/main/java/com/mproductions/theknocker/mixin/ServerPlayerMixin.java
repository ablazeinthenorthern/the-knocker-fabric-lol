package com.mproductions.theknocker.mixin;

import com.mproductions.theknocker.TheKnockerMod;
import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * When a player's respawn point is set (i.e., they've slept in a bed),
 * update any existing Knocker entities in the world with the new home location.
 */
@Mixin(ServerPlayer.class)
public class ServerPlayerMixin {

    @Inject(method = "setRespawnPosition", at = @At("TAIL"))
    private void onSetRespawnPosition(
        net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimensionKey,
        BlockPos pos, float angle, boolean forced, boolean sendMessage,
        CallbackInfo ci
    ) {
        ServerPlayer player = (ServerPlayer) (Object) this;
        if (pos == null) return;

        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        // Tell all nearby Knockers about the new home
        List<KnockerEntity> knockers = serverLevel.getEntitiesOfClass(
            KnockerEntity.class,
            player.getBoundingBox().inflate(256.0),
            e -> true
        );

        for (KnockerEntity knocker : knockers) {
            knocker.setKnownHomePos(pos);
        }
    }
}
