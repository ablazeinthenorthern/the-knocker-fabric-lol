package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/**
 * If The Knocker is in attacking phase and encounters water,
 * he places dirt/cobblestone blocks to bridge across it.
 * This makes him nearly impossible to escape via water.
 */
public class KnockerBridgeGoal extends Goal {

    private final KnockerEntity knocker;
    private int bridgeCooldown = 0;

    public KnockerBridgeGoal(KnockerEntity knocker) {
        this.knocker = knocker;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (knocker.level().isClientSide) return false;
        if (knocker.getPhase() < KnockerEntity.PHASE_ATTACKING) return false;
        if (bridgeCooldown > 0) { bridgeCooldown--; return false; }

        // Check if there's water immediately ahead
        return isWaterAhead();
    }

    @Override
    public boolean canContinueToUse() {
        return false; // One block at a time
    }

    @Override
    public void start() {
        placeNextBridgeBlock();
        bridgeCooldown = 10;
    }

    private boolean isWaterAhead() {
        // Check the block the Knocker is facing
        BlockPos ahead = knocker.blockPosition().relative(knocker.getDirection());
        FluidState fluid = knocker.level().getFluidState(ahead);
        return fluid.is(Fluids.WATER) || fluid.is(Fluids.FLOWING_WATER);
    }

    private void placeNextBridgeBlock() {
        // Find the water block ahead and place a solid block
        for (Direction dir : new Direction[]{knocker.getDirection(), Direction.UP, Direction.DOWN}) {
            BlockPos pos = knocker.blockPosition().relative(dir);
            BlockState state = knocker.level().getBlockState(pos);
            FluidState fluid = knocker.level().getFluidState(pos);

            if (fluid.is(Fluids.WATER) || fluid.is(Fluids.FLOWING_WATER)) {
                // Place cobblestone to bridge
                knocker.level().setBlockAndUpdate(pos, Blocks.COBBLESTONE.defaultBlockState());
                return;
            }
        }
    }
}
