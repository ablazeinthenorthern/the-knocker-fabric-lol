package com.mproductions.theknocker.entity;

import com.mproductions.theknocker.TheKnockerMod;
import com.mproductions.theknocker.goal.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class KnockerEntity extends Monster {

    // -------------------------------------------------------------------------
    // Synced data: phase tracks how aggressive the Knocker currently is
    // -------------------------------------------------------------------------
    private static final EntityDataAccessor<Integer> PHASE =
        SynchedEntityData.defineId(KnockerEntity.class, EntityDataSerializers.INT);

    // Phases
    public static final int PHASE_STALKING = 0;    // Lurking, watching, not yet attacking
    public static final int PHASE_KNOCKING = 1;    // Knocking on the player's base door
    public static final int PHASE_ATTACKING = 2;   // Actively chasing and attacking

    // The Knocker "knows where you live" — stores the player's bed/home position
    private Optional<BlockPos> knownHomePos = Optional.empty();
    private int patienceTimer = 0;          // Counts down before Knocker escalates
    private int patienceMax = 2400;         // ~2 min at 20 TPS before becoming aggressive
    private int jumpscareTimer = 0;
    private int stalkerCooldown = 0;
    private boolean hasKnocked = false;

    // How many times the player has hit the Knocker (becomes more dangerous)
    private int timesHit = 0;

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------
    public KnockerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.setNoGravity(false);
        this.setSilent(false);
    }

    // -------------------------------------------------------------------------
    // Attribute defaults
    // -------------------------------------------------------------------------
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH, 40.0)           // Survives a few hits
            .add(Attributes.MOVEMENT_SPEED, 0.32)       // Slightly faster than player
            .add(Attributes.ATTACK_DAMAGE, 3.0)         // Low damage, very fast attacks
            .add(Attributes.ATTACK_SPEED, 3.0)          // Fast attack speed — the real threat
            .add(Attributes.FOLLOW_RANGE, 64.0)         // Long detection range
            .add(Attributes.KNOCKBACK_RESISTANCE, 0.5); // Resists being knocked away
    }

    // -------------------------------------------------------------------------
    // Data registration
    // -------------------------------------------------------------------------
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(PHASE, PHASE_STALKING);
    }

    // -------------------------------------------------------------------------
    // Goal registration — behaviors change by phase
    // -------------------------------------------------------------------------
    @Override
    protected void registerGoals() {
        // Float in water so he doesn't drown
        this.goalSelector.addGoal(0, new FloatGoal(this));

        // Knock on nearby doors (phase 0+)
        this.goalSelector.addGoal(1, new KnockerDoorGoal(this));

        // Jumpscare the player if they look at The Knocker (phase 0+)
        this.goalSelector.addGoal(2, new KnockerJumpscareGoal(this));

        // Stalk/disappear when looked at (phase 0)
        this.goalSelector.addGoal(3, new KnockerStalkGoal(this));

        // Bridge over water using blocks (phase 2)
        this.goalSelector.addGoal(4, new KnockerBridgeGoal(this));

        // Melee attack (phase 2 only, very fast)
        this.goalSelector.addGoal(5, new KnockerMeleeAttackGoal(this));

        // Wander near known home pos (phase 0–1)
        this.goalSelector.addGoal(6, new KnockerLurknearHomeGoal(this));

        // Random stray wander (lowest priority)
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        // Target nearest player
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // -------------------------------------------------------------------------
    // Tick
    // -------------------------------------------------------------------------
    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide) return;

        Player nearestPlayer = this.level().getNearestPlayer(this, 64.0);

        // Patience countdown — the longer the world progresses the angrier he gets
        if (getPhase() < PHASE_ATTACKING) {
            patienceTimer++;
            if (patienceTimer >= patienceMax) {
                escalatePhase();
                patienceTimer = 0;
                patienceMax = Math.max(400, patienceMax - 200);
            }
        }

        // Ambient knocking sounds
        if (!this.level().isClientSide && this.random.nextInt(400) == 0) {
            playAmbientKnocking(nearestPlayer);
        }

        // Apply darkness + blindness when attacking and player is close
        if (getPhase() == PHASE_ATTACKING && nearestPlayer != null) {
            double dist = this.distanceTo(nearestPlayer);
            if (dist < 6.0 && nearestPlayer instanceof ServerPlayer sp) {
                if (timesHit >= 3) {
                    applyDarknessEffect(sp);
                }
            }
        }

        // Track home position from last sleeping player
        if (knownHomePos.isEmpty() && nearestPlayer != null) {
            if (nearestPlayer.isSleeping()) {
                knownHomePos = Optional.of(nearestPlayer.blockPosition());
            }
        }
    }

    private void playAmbientKnocking(@Nullable Player nearestPlayer) {
        if (nearestPlayer == null) return;
        double dist = this.distanceTo(nearestPlayer);
        if (dist < 32) {
            // Play knocking sound near player's location (heard through walls)
            this.level().playSound(
                null,
                nearestPlayer.blockPosition(),
                SoundEvents.WOOD_HIT,
                SoundSource.HOSTILE,
                0.8f,
                0.7f + this.random.nextFloat() * 0.3f
            );
        }
    }

    private void applyDarknessEffect(ServerPlayer player) {
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            net.minecraft.world.effect.MobEffects.DARKNESS, 60, 0, false, false));
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            net.minecraft.world.effect.MobEffects.BLINDNESS, 40, 0, false, false));
    }

    // -------------------------------------------------------------------------
    // Phase escalation
    // -------------------------------------------------------------------------
    public void escalatePhase() {
        int current = getPhase();
        if (current < PHASE_ATTACKING) {
            setPhase(current + 1);
            if (!this.level().isClientSide) {
                TheKnockerMod.LOGGER.debug("[TheKnocker] Escalated to phase {}", current + 1);
            }
        }
    }

    public int getPhase() {
        return this.entityData.get(PHASE);
    }

    public void setPhase(int phase) {
        this.entityData.set(PHASE, phase);
    }

    // -------------------------------------------------------------------------
    // Home position (the "knows where you live" mechanic)
    // -------------------------------------------------------------------------
    public Optional<BlockPos> getKnownHomePos() {
        return knownHomePos;
    }

    public void setKnownHomePos(BlockPos pos) {
        this.knownHomePos = Optional.of(pos);
    }

    // -------------------------------------------------------------------------
    // Damaged — becomes more dangerous each time hit
    // -------------------------------------------------------------------------
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && source.getEntity() instanceof Player) {
            timesHit++;
            // After 3 hits, escalate to attacking phase immediately
            if (timesHit >= 3 && getPhase() < PHASE_ATTACKING) {
                setPhase(PHASE_ATTACKING);
            }
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // Don't despawn naturally once the player has seen him
    // -------------------------------------------------------------------------
    @Override
    public boolean requiresCustomPersistence() {
        return getPhase() > PHASE_STALKING || hasKnocked;
    }

    // -------------------------------------------------------------------------
    // Drops — 8.5% chance to drop his knife
    // -------------------------------------------------------------------------
    @Override
    protected void dropCustomDeathLoot(ServerLevelAccessor level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (this.random.nextFloat() < 0.085f) {
            this.spawnAtLocation(new ItemStack(TheKnockerMod.KNOCKER_KNIFE));
        }
    }

    // -------------------------------------------------------------------------
    // Sounds
    // -------------------------------------------------------------------------
    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return SoundEvents.AMBIENT_CAVE.value(); // Creepy ambient
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT; // Human-like hurt sound
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.4f; // Quiet — hard to detect
    }

    // -------------------------------------------------------------------------
    // NBT save/load
    // -------------------------------------------------------------------------
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase());
        tag.putInt("PatienceTimer", patienceTimer);
        tag.putInt("TimesHit", timesHit);
        tag.putBoolean("HasKnocked", hasKnocked);
        knownHomePos.ifPresent(pos -> {
            tag.putInt("HomeX", pos.getX());
            tag.putInt("HomeY", pos.getY());
            tag.putInt("HomeZ", pos.getZ());
        });
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setPhase(tag.getInt("Phase"));
        patienceTimer = tag.getInt("PatienceTimer");
        timesHit = tag.getInt("TimesHit");
        hasKnocked = tag.getBoolean("HasKnocked");
        if (tag.contains("HomeX")) {
            knownHomePos = Optional.of(new BlockPos(
                tag.getInt("HomeX"),
                tag.getInt("HomeY"),
                tag.getInt("HomeZ")
            ));
        }
    }

    // -------------------------------------------------------------------------
    // Spawn conditions — only spawns in the Overworld, near doors, in darkness
    // -------------------------------------------------------------------------
    public static boolean checkKnockerSpawnRules(
        EntityType<KnockerEntity> type,
        ServerLevelAccessor level,
        EntitySpawnReason reason,
        BlockPos pos,
        RandomSource random
    ) {
        // Only spawn at night, in darkness
        if (level.getDayTime() % 24000L < 13000L) return false;
        if (level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK, pos) > 4) return false;
        return Monster.checkMonsterSpawnRules(type, level, reason, pos, random);
    }

    public boolean isHasKnocked() {
        return hasKnocked;
    }

    public void setHasKnocked(boolean hasKnocked) {
        this.hasKnocked = hasKnocked;
    }
}
