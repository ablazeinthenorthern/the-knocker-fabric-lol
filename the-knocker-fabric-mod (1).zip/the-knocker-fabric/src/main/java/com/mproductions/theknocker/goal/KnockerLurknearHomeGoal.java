package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * The Knocker "knows where you live."
 * This goal makes him wander near the player's known home position —
 * so when you log back in, he might be right outside your door.
 */
public class KnockerLurknearHomeGoal extends Goal {

    private final KnockerEntity knocker;
    private int wanderTimer = 0;

    public KnockerLurknearHomeGoal(KnockerEntity knocker) {
        this.knocker = knocker;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (knocker.level().isClientSide) return false;
        return knocker.getKnownHomePos().isPresent()
            && knocker.getPhase() <= KnockerEntity.PHASE_KNOCKING
            && knocker.random.nextInt(40) == 0;
    }

    @Override
    public boolean canContinueToUse() {
        return wanderTimer > 0 && knocker.getPhase() <= KnockerEntity.PHASE_KNOCKING;
    }

    @Override
    public void start() {
        wanderTimer = 100 + knocker.random.nextInt(100);
        moveToNearHome();
    }

    @Override
    public void tick() {
        wanderTimer--;
        if (wanderTimer % 40 == 0) {
            moveToNearHome(); // Occasionally re-path
        }
    }

    @Override
    public void stop() {
        knocker.getNavigation().stop();
    }

    private void moveToNearHome() {
        knocker.getKnownHomePos().ifPresent(home -> {
            // Move to a random spot within 8 blocks of home
            int ox = knocker.random.nextInt(16) - 8;
            int oz = knocker.random.nextInt(16) - 8;
            BlockPos target = home.offset(ox, 0, oz);
            knocker.getNavigation().moveTo(
                target.getX() + 0.5,
                target.getY(),
                target.getZ() + 0.5,
                0.9
            );
        });
    }
}
