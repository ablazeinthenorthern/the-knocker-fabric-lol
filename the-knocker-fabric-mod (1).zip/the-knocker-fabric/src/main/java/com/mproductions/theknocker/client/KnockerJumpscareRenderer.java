package com.mproductions.theknocker.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Tracks jumpscare state for the client.
 * When triggered, applies a brief screen-darkening effect.
 * The actual rendering hook is injected via GameRendererMixin.
 */
@Environment(EnvType.CLIENT)
public class KnockerJumpscareRenderer {

    private static int jumpscareTicksRemaining = 0;
    private static final int JUMPSCARE_DURATION = 15; // ticks

    public static void triggerJumpscare() {
        jumpscareTicksRemaining = JUMPSCARE_DURATION;
    }

    /**
     * Called each render frame. Returns the intensity of the jumpscare effect (0.0–1.0).
     */
    public static float getJumpscareIntensity() {
        if (jumpscareTicksRemaining <= 0) return 0.0f;
        // Peaks immediately, fades out
        return jumpscareTicksRemaining / (float) JUMPSCARE_DURATION;
    }

    /**
     * Called each tick from the mixin to decrement the timer.
     */
    public static void tick() {
        if (jumpscareTicksRemaining > 0) {
            jumpscareTicksRemaining--;
        }
    }

    public static boolean isActive() {
        return jumpscareTicksRemaining > 0;
    }
}
