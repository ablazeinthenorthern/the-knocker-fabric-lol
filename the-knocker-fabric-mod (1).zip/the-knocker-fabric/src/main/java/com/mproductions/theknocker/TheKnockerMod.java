package com.mproductions.theknocker;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TheKnockerMod implements ModInitializer {

    public static final String MOD_ID = "the_knocker";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // The Knocker entity type
    public static EntityType<KnockerEntity> KNOCKER_ENTITY_TYPE;

    // The Knife item (8.5% drop from The Knocker)
    public static Item KNOCKER_KNIFE;

    @Override
    public void onInitialize() {
        LOGGER.info("The Knocker awakens...");

        // Register entity type
        KNOCKER_ENTITY_TYPE = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "knocker"),
            FabricEntityTypeBuilder.create(MobCategory.MONSTER, KnockerEntity::new)
                .dimensions(EntityDimensions.scalable(0.6f, 1.95f))
                .trackRangeBlocks(128)
                .trackedUpdateRate(3)
                .build()
        );

        // Register knife item
        KNOCKER_KNIFE = Registry.register(
            BuiltInRegistries.ITEM,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "knocker_knife"),
            new KnockerKnifeItem(new Item.Properties()
                .stacksTo(1)
                .durability(0))
        );

        LOGGER.info("The Knocker has registered its entity and items.");
    }
}
