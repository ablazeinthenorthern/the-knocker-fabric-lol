package com.mproductions.theknocker.goal;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;

/**
 * Overrides the standard melee attack goal to:
 * - Only activate in PHASE_ATTACKING
 * - Apply very fast attack speed (consistent with original mod's dangerous-but-low-damage design)
 * - Chase the player aggressively, including across water if needed
 */
public class KnockerMeleeAttackGoal extends MeleeAttackGoal {

    private final KnockerEntity knocker;

    public KnockerMeleeAttackGoal(KnockerEntity knocker) {
        super(knocker, 1.3, false); // speed 1.3x, can pursue off-path
        this.knocker = knocker;
    }

    @Override
    public boolean canUse() {
        return knocker.getPhase() == KnockerEntity.PHASE_ATTACKING && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        return knocker.getPhase() == KnockerEntity.PHASE_ATTACKING && super.canContinueToUse();
    }

    @Override
    protected double getAttackReachSqr(LivingEntity target) {
        // Slightly longer reach — knife lunges
        return super.getAttackReachSqr(target) * 1.2;
    }
}
