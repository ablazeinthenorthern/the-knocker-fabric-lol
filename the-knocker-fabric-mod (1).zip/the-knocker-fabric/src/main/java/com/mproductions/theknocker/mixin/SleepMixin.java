package com.mproductions.theknocker.mixin;

import com.mproductions.theknocker.TheKnockerMod;
import com.mproductions.theknocker.entity.KnockerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * When a player starts sleeping, there's a chance The Knocker will spawn
 * near their bed. He then "knows where they live."
 */
@Mixin(Player.class)
public class SleepMixin {

    @Inject(method = "startSleepInBed", at = @At("TAIL"))
    private void onStartSleep(BlockPos bedPos, CallbackInfo ci) {
        Player player = (Player) (Object) this;
        if (player.level().isClientSide) return;
        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        // ~20% chance of The Knocker spawning when player sleeps
        if (player.level().random.nextFloat() > 0.20f) return;

        // Check if a Knocker already exists nearby
        boolean knockerAlreadyNearby = !serverLevel.getEntitiesOfClass(
            KnockerEntity.class,
            player.getBoundingBox().inflate(128.0),
            e -> true
        ).isEmpty();

        if (knockerAlreadyNearby) return;

        // Spawn Knocker 10-20 blocks outside the player's base, at night
        for (int attempt = 0; attempt < 20; attempt++) {
            int ox = (serverLevel.random.nextInt(20) + 10) * (serverLevel.random.nextBoolean() ? 1 : -1);
            int oz = (serverLevel.random.nextInt(20) + 10) * (serverLevel.random.nextBoolean() ? 1 : -1);
            BlockPos spawnPos = bedPos.offset(ox, 0, oz);
            spawnPos = serverLevel.getHeightmapPos(
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                spawnPos
            );

            if (serverLevel.getBrightness(net.minecraft.world.level.LightLayer.BLOCK, spawnPos) < 4) {
                KnockerEntity knocker = TheKnockerMod.KNOCKER_ENTITY_TYPE.create(
                    serverLevel,
                    net.minecraft.world.entity.EntitySpawnReason.EVENT
                );
                if (knocker != null) {
                    knocker.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                    knocker.setKnownHomePos(bedPos); // He knows where you sleep
                    serverLevel.addFreshEntity(knocker);
                    TheKnockerMod.LOGGER.debug("[TheKnocker] Spawned near sleeping player at {}", spawnPos);
                }
                break;
            }
        }
    }
}
