package com.mproductions.theknocker.client;

import com.mproductions.theknocker.entity.KnockerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public class KnockerEntityRenderer extends HumanoidMobRenderer<KnockerEntity, HumanoidModel<KnockerEntity>> {

    private static final ResourceLocation TEXTURE =
        ResourceLocation.fromNamespaceAndPath("the_knocker", "textures/entity/knocker.png");

    public KnockerEntityRenderer(EntityRendererProvider.Context context) {
        super(
            context,
            new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)),
            0.5f // shadow radius
        );
    }

    @Override
    public ResourceLocation getTextureLocation(KnockerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected boolean isShaking(KnockerEntity entity) {
        return false;
    }
}
