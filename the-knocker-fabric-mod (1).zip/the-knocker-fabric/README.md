# The Knocker — Fabric Port

**Minecraft 26.1.2 | Fabric Loader 0.18.4 | Fabric API 0.150.0+26.1.2**

A faithful Fabric port of the original Forge mod **The Knocker** by M_Productions.
Adds a terrifying, humanoid stalker entity that follows your every step, knows where you live, and may visit you while you sleep.

---

## Requirements

| Dependency | Version |
|---|---|
| Minecraft | 26.1.2 |
| Java | 25+ |
| Fabric Loader | 0.18.4+ |
| Fabric API | 0.150.0+26.1.2 |
| Gradle | 9.4.0 |
| Loom | 1.15 |

> **Note:** Minecraft 26.1 is the first unobfuscated release. This mod uses Mojang's official mappings.
> No mods from 1.21.11 or earlier will work with 26.1.x without recompilation.

---

## Features

### The Knocker Entity
- Pitch-black humanoid with a pale white face — blends into shadows
- Spawns naturally at **night** in the **Overworld**, in dark areas
- Higher chance of spawning near **doors and trapdoors**

### Behavior Phases

**Phase 0 — Stalking**
- Lurks at the edge of visibility (~20 blocks away)
- Disappears (teleports) when directly looked at
- May jumpscare the player when spotted
- Watches silently; plays faint ambient knocking sounds

**Phase 1 — Knocking**
- Walks to the player's base and **knocks on doors and trapdoors**
- The knocking sound is audible through walls
- Escalates after ~2 minutes of patience

**Phase 2 — Attacking**
- Actively chases and attacks — low damage but **very fast attack speed**
- Applies **Darkness + Blindness** to the player after being hit a few times
- Can **place blocks to bridge over water** — no running to an island
- Can **swim underwater** to pursue the player

### "Knows Where You Live"
- Tracks the player's **bed/respawn position**
- Lurks near your base even when you're not there
- When you log back in at night, he may already be waiting outside

### Sleep Trigger
- **~20% chance** of spawning when a player sleeps in a bed
- Spawns 10–20 blocks outside the base in darkness
- Immediately knows the bed location

### The Knocker's Knife
- **8.5% drop rate** on death
- Low damage but serves as a rare trophy item

### Does Not Despawn
- Once The Knocker has knocked on your door or been hit, he **will not despawn**
- Each time you hit him (3+ times), he becomes more dangerous

---

## Building

```bash
# Requires Java 25 and Gradle 9.4.0
./gradlew build
```

Output JAR will be at `build/libs/the-knocker-fabric-1.0.0+26.1.2.jar`

### IntelliJ IDEA Setup
- Requires **IntelliJ IDEA 2025.3+** for Mixin support in MC 26.1
- Set Gradle JVM to Java 25 in `Settings > Build > Gradle`

---

## File Structure

```
src/main/java/com/mproductions/theknocker/
├── TheKnockerMod.java              # Main mod init, entity/item registration
├── KnockerKnifeItem.java           # The rare knife drop item
├── entity/
│   └── KnockerEntity.java         # Core entity: phases, AI, NBT, drops
├── goal/
│   ├── KnockerStalkGoal.java      # Stalking + disappear-when-looked-at
│   ├── KnockerJumpscareGoal.java  # Jumpscare trigger
│   ├── KnockerDoorGoal.java       # Navigate to and knock on doors
│   ├── KnockerMeleeAttackGoal.java# Fast melee in phase 2
│   ├── KnockerBridgeGoal.java     # Bridge over water with blocks
│   └── KnockerLurknearHomeGoal.java # Lurk near known home position
├── mixin/
│   ├── SleepMixin.java            # Spawn trigger on player sleep
│   ├── ServerPlayerMixin.java     # Track home pos on respawn set
│   └── GameRendererMixin.java     # Client screen effect hook
└── client/
    ├── TheKnockerClient.java      # Client entrypoint
    ├── KnockerEntityRenderer.java # Humanoid renderer with dark texture
    └── KnockerJumpscareRenderer.java # Jumpscare screen effect state
```

---

## Textures Needed

You need to add the following texture files:
- `src/main/resources/assets/the_knocker/textures/entity/knocker.png`
  — A 64x64 humanoid skin texture: all black body, pale/white face
- `src/main/resources/assets/the_knocker/icon.png` — 128x128 mod icon

Sound files (optional — the mod falls back to vanilla sounds):
- `src/main/resources/assets/the_knocker/sounds/knock.ogg`
- `src/main/resources/assets/the_knocker/sounds/jumpscare.ogg`
- `src/main/resources/assets/the_knocker/sounds/ambient.ogg`

---

## Credits

- Original mod: **The Knocker** by **M_Productions** (Forge/NeoForge)
- Original concept by the creators of **The Man From The Fog**
- Fabric port: community contribution

---

## License

Custom license — see original mod page.
